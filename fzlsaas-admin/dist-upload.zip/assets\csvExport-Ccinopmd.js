function o(t){const e=String(t??"");return/[",\n\r]/.test(e)?`"${e.replace(/"/g,'""')}"`:e}function i(t,e,s){const r=[e.map(o).join(","),...s.map(l=>l.map(o).join(","))],a=new Blob(["\uFEFF"+r.join(`
`)],{type:"text/csv;charset=utf-8"}),c=URL.createObjectURL(a),n=document.createElement("a");n.href=c,n.download=t.endsWith(".csv")?t:`${t}.csv`,n.click(),URL.revokeObjectURL(c)}export{i as d};
