function t(n){return n?new Date(n*1e3).toLocaleString("zh-CN"):"—"}function r(n){return`¥${Number(n||0).toFixed(2)}`}export{t as a,r as f};
